#include<stdio.h>
#include<time.h>
#include<iostream>
#include<string>
#include<iomanip>
#include<cstdlib>
#include<stdlib.h>
#include<process.h>
#include<string.h>
#include<fstream>
#include<conio.h>

using namespace std;

int scr=0;

typedef unsigned int uint;

enum movDir { UP, DOWN, LEFT, RIGHT };

void login();
void disp();

class user
{
   public:
       char uname[10];
       int score;
}u,uy;

class tile
{
    public:
      tile(): val( 0 ), blocked( false ) {}
       uint val;
        bool blocked;
};

void writescore()
{
    int flag=0;
    u.score=scr;
    ifstream fi;
    ofstream fo;
    fi.open("score.dat",ios::in|ios::binary);
    long pos;
    while(!fi.eof())
    {
        pos=fi.tellg();
        fi.read((char*)&uy,sizeof(uy));
        if(!strcmp(u.uname,uy.uname))
        {
            flag=1;
            break;
        }
    }
    fi.close();
    fo.open("score.dat",ios::app|ios::binary);
    if(flag==1)
    {
        fo.write((char*)&u,sizeof(u));
    }
    else
    {
        fo.write((char*)&u,sizeof(u));

    }

    fo.close();
}


void main_menu()
{
    int ch;
    cout<<"\n\n\n\n\n\n\n\n\n\t\t\t1.login and play\n";
    cout<<"\t\t\t2.display scoreboard\n\t\t\t3.Exit\n\n";
    cout<<"\t\t\tEnter choice : ";cin>>ch;
    do {
            switch(ch)
            {
                case 1 : login();break;
                case 2 : disp();break;
                case 3 : exit(0);
                default: cout<<"\t\t\tre-Enter your choice : ";cin>>ch;
            }
        }while(ch<4);

}


class g2048
{

    public:
      g2048() : done( false ), win( false ), moved( true ), score( 0 ) {}

      void loop()
      {
	     system("cls");
	     addTile();
	     while( true )
	     {
	         if( moved )
               addTile();

	          drawBoard();
             if( done ) break;

	          waitKey();
	      }
	     string s = "Game Over!";

	     if( win ) s = "You've made it!";
	     cout << s << endl << endl;
      }

    private:

      void drawBoard()
      {

	    system( "cls" );
        cout << "SCORE: " << score <<"  " << endl << endl;
        for( int y = 0; y < 4; y++ )
	    {
	        cout << "+------+------+------+------+" << endl << "| ";
	           for( int x = 0; x < 4; x++ )
               {
		            if( !board[x][y].val ) cout << setw( 4 ) << " ";
                    else cout << setw( 4 ) << board[x][y].val;

		            cout << " | ";
	            }
            cout << endl;
	     }
	     cout << "+------+------+------+------+" << endl << endl;
       }

       void waitKey()
       {
	      moved = false; char c;
	      cout << "(W)Up (S)Down (A)Left (D)Right (Q)Exit"; c=getche(); c &= 0x5F;

	      switch( c )
	      {
	          case 'W': move( UP );break;
              case 'A': move( LEFT ); break;
	          case 'S': move( DOWN ); break;
	          case 'D': move( RIGHT );break;
	          case 'Q': {
	                     writescore();
	                     system("cls");
                         cout<<u.uname<<" logged out";
                         main_menu();

                         }
	      }

	      for( int y = 0; y < 4; y++ )
	      for( int x = 0; x < 4; x++ )
		  board[x][y].blocked = false;
       }

       void addTile()
       {
           for( int y = 0; y < 4; y++ )
	         for( int x = 0; x < 4; x++ )
		        if( !board[x][y].val )
		        {
		           uint a, b;
                   do
		           {
		               a = rand() % 4; b = rand() % 4;
                    }while( board[a][b].val );

		            int s = rand() % 100;

		               if( s > 89 ) board[a][b].val = 4;
		               else board[a][b].val = 2;
		               if( canMove() ) return;
                }
	            done = true;
        }

        bool canMove()
        {
	        for( int y = 0; y < 4; y++ )
	           for( int x = 0; x < 4; x++ )
		          if( !board[x][y].val ) return true;

            for( int y = 0; y < 4; y++ )
              for( int x = 0; x < 4; x++ )
              {
		         if( testAdd( x + 1, y, board[x][y].val ) ) return true;
                 if( testAdd( x - 1, y, board[x][y].val ) ) return true;
                 if( testAdd( x, y + 1, board[x][y].val ) ) return true;
                 if( testAdd( x, y - 1, board[x][y].val ) ) return true;
	           }
	        return false;
        }

        bool testAdd( int x, int y, uint v )
        {
	        if( x < 0 || x > 3 || y < 0 || y > 3 ) return false;
	        return board[x][y].val == v;
        }

        void moveVert( int x, int y, int d )
        {
	       if( board[x][y + d].val && board[x][y + d].val == board[x][y].val && !board[x][y].blocked && !board[x][y + d].blocked  )
	       {
	            board[x][y].val = 0;
	            board[x][y + d].val *= 2;
                score += board[x][y + d].val;
                scr=score;
	            board[x][y + d].blocked = true;
	            moved = true;
           }
	       else if( !board[x][y + d].val && board[x][y].val )
	       {
                board[x][y + d].val = board[x][y].val;
	            board[x][y].val = 0;
	            moved = true;
	       }
	       if( d > 0 ) { if( y + d < 3 ) moveVert( x, y + d,  1 ); }
           else        { if( y + d > 0 ) moveVert( x, y + d, -1 ); }
        }

        void moveHori( int x, int y, int d )
        {
	       if( board[x + d][y].val && board[x + d][y].val == board[x][y].val && !board[x][y].blocked && !board[x + d][y].blocked  )
	       {
	           board[x][y].val = 0;
	           board[x + d][y].val *= 2;
	           score += board[x + d][y].val;
	           scr=score;
               board[x + d][y].blocked = true;
	           moved = true;
           }
	       else if( !board[x + d][y].val && board[x][y].val )
	       {
               board[x + d][y].val = board[x][y].val;
	           board[x][y].val = 0;
               moved = true;
           }
	       if( d > 0 ) { if( x + d < 3 ) moveHori( x + d, y,  1 ); }
           else        { if( x + d > 0 ) moveHori( x + d, y, -1 ); }
         }

         void move( movDir d )
         {
	           switch( d )
	           {
	             case UP:
	    	               for( int x = 0; x < 4; x++ )
		                   {
		                       int y = 1;
		                       while( y < 4 )
                               { if( board[x][y].val ) moveVert( x, y, -1 ); y++;}
		                   }
		                   break;
	             case DOWN:
		                    for( int x = 0; x < 4; x++ )
		                    {
                               int y = 2;
		                       while( y >= 0 )
		                       { if( board[x][y].val ) moveVert( x, y, 1 ); y--;}
                            }
		                    break;
	             case LEFT:
		                     for( int y = 0; y < 4; y++ )
		                     {
		                        int x = 1;
		                        while( x < 4 )
		                        { if( board[x][y].val ) moveHori( x, y, -1 ); x++;}
                             }
		                     break;
	             case RIGHT:
		                      for( int y = 0; y < 4; y++ )
                              {
		                         int x = 2;
		                         while( x >= 0 )
                                 { if( board[x][y].val ) moveHori( x, y, 1 ); x--;}
                              }
	            }
         }

         tile board[4][4];
         bool win, done, moved;
         uint score;
}g;

void login()
{
    char takeme[1];
    gets(takeme);
    srand( static_cast<uint>( time( NULL ) ) );
    cout<<"\n\t\t\tEnter Username : ";

    gets(u.uname);

    g.loop();



}


void disp()
{
    int temp=0;
    system("cls");
    ifstream openfile ("score.dat",ios::in);
    if(openfile.is_open())
    {
        while(!openfile.eof())
        {if (!openfile.eof()) break;
            openfile.read((char*)&u,sizeof(u));
            cout<<u.uname<<" "<<u.score << endl;

        }

    }

     openfile.close();
     getch();
     system("cls");
     main_menu();
}


int main( int argc, char* argv[] )
{
    main_menu();
    return 0 ;
}
