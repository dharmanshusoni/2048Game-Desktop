<?php
session_start();
mysql_connect("localhost","root","") or die("Connection Error");
mysql_select_db("maritime") or die("Database not found");
error_reporting(0);

$query="SELECT * FROM candidate WHERE id='".$_GET['id']."'";
            $result = mysql_query($query);
            $row=mysql_fetch_array($result);

if(isset($_GET['search']))
{
    if($_GET['ss']===1)
        header("location:view_job.php?v=".$_GET['ss']."&d=".$_GET['dept']."&r=".$_GET['rank']."&s=".$_GET['ship']."");   
    else
        header("location:view_cv.php?v=".$_GET['ss']."&d=".$_GET['dept']."&r=".$_GET['rank']."&s=".$_GET['ship']."");   
}

?>
<html>
    <head>
        
        <title>Candidate Login</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    <!-- Optional theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
        
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
        <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="CSS/style.css"/>

    
    </head>
    <body>
        
          <div class="container-fluid">
              <?php include_once("includes/header.php");?>
        <div class="container">
            <?php include_once("includes/leftpanel.php");?>          
              </div>
            <div class="col-lg-6">
                <form class="form-group border">
                    <div>
                        <h1 align=center>Candidate</h1>
                        <br/>
                        <label>Name</label>
                        <input type="text" name="" disabled class="form-control form-group" value="<?php echo $row[1]; ?>">
                    </div>
                    <div>
                        <label>Email</label>
                        <input type="email" name="" disabled class="form-control form-group" value="<?php echo $row[15]; ?>">
                    </div>
                    <div>
                        <label>Contact No (Mobile)</label>
                        <input type="text" name="" disabled class="form-control form-group" value="<?php echo $row[3]; ?>">
                    </div>
                    <div>
                        <label>Number (Land-line)</label>
                        <input type="text" name="" disabled class="form-control form-group" value="<?php echo $row[4]; ?>">
                    </div>
                    <div>
                        <label>DOB</label>
                        <input type="date" name="" disabled class="form-control form-group" value="<?php echo $row[5]; ?>">
                    </div>
                    <div>
                        <label>Country</label>
                        <input type="text" name="ccnt" disabled class="form-control form-group" value="<?php echo $row[6]; ?>">
                        
                    </div>
                    <div>
                        <label>CoC Grade</label>
                        <input type="text" name="" disabled class="form-control form-group" value="<?php echo $row[7]; ?>">
                    </div>
                    <div>
                        <label>Place of Issue</label>
                        <input type="text" name="" disabled class="form-control form-group" value="<?php echo $row[8]; ?>">
                    </div>
                    <div>
                        <label>Current Rank</label>
                        <input type="text" name="ccr" disabled class="form-control form-group"value="<?php echo $row[9]; ?>">
                    </div>
                    <div>
                        <label>Ship</label>
                        <input type="text" name="cship" disabled class="form-control form-group"value="<?php echo $row[10]; ?>">
                    </div>
                    <div>
                        <label>Position Applied for</label>
                        <input type="text" name="ccnt" disabled class="form-control form-group"value="<?php echo $row[11]; ?>">
                    </div>
                    <div>
                        <label>Last Salary</label>
                        <input type="text" name="" disabled class="form-control form-group"value="<?php echo $row[12]; ?>">
                    </div>
                    <div>
                        <label>Rank Experience</label>
                        <input type="text" name="" disabled class="form-control form-group"value="<?php echo $row[13]; ?>">
                    </div>
                    <div>
                        <label>Availablity Date</label>
                        <input type="date" name="" disabled class="form-control form-group"value="<?php echo $row[14]; ?>">
                    </div>
                </form>
                
            </div>
            <div class="col-lg-3">
                <?php
                ?>
                
            
            </div>
        </div>
        <?php include_once("includes/footer.php");?>
    </body>
</html>