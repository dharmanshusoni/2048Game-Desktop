<?php
session_start();

unset($_SESSION['u']);
session_destroy($_SESSION);
header("location:index.php");


?>