<?php
session_start();

error_reporting(0);
mysql_connect("localhost","root","") or die("Connection Error");
mysql_select_db("maritime") or die("Database not found");

if(isset($_POST['login']))
{
      $query="SELECT * FROM admin WHERE uname='".$_POST['uname']."'";
        $result = mysql_query($query);
        $num_rows = mysql_num_rows($result);
        if($num_rows)
        {
            $row=mysql_fetch_array($result);
            if($_POST['password']===$row[2])
            {
                $_SESSION['u1']=$_POST['uname'];
                header("location:admin.php");
            }
        }
}
        

?>
<html>
<head>
    <title>Admin Login</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">

    </head>
    
    <body>
    <div class="container-fluid">
        <div class="row" style="padding-top:60px;">
            <div class="col-md-8 col-md-offset-2 col-sm-12 col-xs-12">
                <h1 class="display-1 text-center">Welcome To Admin Login Panel</h1>
            </div>
            </div>
            <div class="row">
                <div class="col-md-4 col-md-offset-4 md-form">
                    <br>
                    <form class="form" method="post" style="padding-top:110px">
                    <label for="username">Username </label><br/>   
                        <input type="text" required name="uname" id=username class="form-control"><br/>
                    <label for="password">Password </label><br/>
                        <input type="password" required name="password" class="form-control"><br/>
                        <input type="submit" name="login" class="btn btn-lg  btn btn-block" value="Login">
                </form>
                </div>
            </div>
        </div>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    </body>
</html>