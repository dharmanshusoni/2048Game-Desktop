<?php
session_start();
include_once("redirect/redirect.php");
mysql_connect("localhost","root","") or die("Connection Error");
mysql_select_db("maritime") or die("Database not found");
error_reporting(0);
$_SESSION['u1'];
 $query="SELECT * FROM company WHERE id='".$_GET['id']."'";
            $result = mysql_query($query);
            $row=mysql_fetch_array($result);

 $cnm=$row[1];
 $ccpr=$row[2];
 $cemail=$row[3];
 $ccnum=$row[4];
 $cfax=$row[5];
 $caddr=$row[6];
 $ccity=$row[7];
 $cstate=$row[8];
 $ccnt=$row[9];
 $csite=$row[10];
$imagepathapp=$row[12];
$imagepathlogo=$row[11];

if(isset($_POST['submit']))
{
    
            if($_FILES['clogo']['name']!==NULL)
            {
                $imagename=$_FILES['clogo']['name'];
                $imagesize=$_FILES['clogo']['size'];
                $imagetype=$_FILES['clogo']['type'];
                $imagetmppath=$_FILES['clogo']['tmp_name'];
                $imagenewsize=$imagesize/1024;
                $imageext=substr($imagename,-4);
                $rno=rand(999,9999);
                $newimagename=$rno.$imagename;
                $imagepathlogo="images/company/logo/".$newimagename;
                 move_uploaded_file($imagetmppath,$imagepathlogo);
            }
        
            if($_FILES['capp']['name']!==NULL)
            {
                 $imagename=$_FILES['capp']['name'];
                $imagesize=$_FILES['capp']['size'];
                $imagetype=$_FILES['capp']['type'];
                $imagetmppath=$_FILES['capp']['tmp_name'];
                $imagenewsize=$imagesize/1024;
                $imageext=substr($imagename,-4);
                $rno=rand(999,9999);
                $newimagename=$rno.$imagename;
                $imagepathapp="images/company/app/".$newimagename;
                move_uploaded_file($imagetmppath,$imagepathapp);
            }
        
    
    echo $query="update company set cnm='".$_POST['cnm']."',
                            cpr='".$_POST['ccpr']."',
                            email='".$_POST['cemail']."',
                            cnn='".$_POST['ccnum']."',
                            fax='".$_POST['cfax']."',
                            caddr='".$_POST['caddr']."',
                            ccity='".$_POST['ccity']."',
                            cstate='".$_POST['cstate']."',
                            ccnt='".$_POST['ccnt']."',
                            website='".$_POST['csite']."',
                            clogo='".$imagepathlogo."',
                            capp='".$imagepathapp."'
                            where id='".$_GET['id']."'";
     $rs=mysql_query($query);
    header("location:company.php");
    
    
}

?>
<html>
    <head>
        <title>Company Login</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    <!-- Optional theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
        <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="CSS/style.css"/>
    </head>
    <body>
        <?php include_once("../admin/includes/admin_header.php");?>
        
          <div class="container-fluid">
            
        <div class="container ">
            
            </div>
            <div class="col-lg-6">
                <form method="post" class="border" enctype="multipart/form-data">
                <div>
                    <h1 align="center">Update Details</h1>
                    <br/>
                    <label>Company Name</label>
                    <input type="text"  class="form-control form-group" name="cnm" value="<?php echo $cnm; ?>">
                </div>
                <div>
                    <label>Contact Person</label>
                    <input type="text"  class="form-control form-group" name="ccpr" value="<?php echo $ccpr; ?>">
                </div>
                <div>
                    <label>Email</label>
                    <input type="email"  class="form-control form-group" name="cemail" value="<?php echo $cemail; ?>">
                </div>
                <div>
                    <label>Contact Number</label>
                    <input type="text"  class="form-control form-group" name="ccnum" value="<?php echo $ccnum; ?>">
                </div>
                <div>
                    <label>Fax</label>
                    <input type="text" class="form-control form-group" name="cfax" value="<?php echo $cfax; ?>">
                </div>
                <div>
                    <label>Company Address</label>
                    <input type="text"  class="form-control form-group" name="caddr" value="<?php echo $caddr; ?>">
                </div>
                <div>
                    <label>City</label>
                    <input type="text"  class="form-control form-group" name="ccity" value="<?php echo $ccity; ?>">
                </div>
                <div>
                    <label>State</label>
                    <input type="text"  class="form-control form-group" name="cstate" value="<?php echo $cstate; ?>">
                </div>
                <div>
                    <label>Country</label>
                  <select class="form-control form-group" required name="ccnt">
                        <option value="Afghanistan">Afghanistan</option>
                        <option value="Albania">Albania</option>
                        <option value="Algeria">Algeria</option>
                        <option value="American Samoa">American Samoa</option>
                        <option value="Angola">Angola</option>
                        <option value="Anguilla">Anguilla</option>
                        <option value="Antarctica">Antarctica</option>
                        <option value="Antigua And Barbuda">Antigua And Barbuda</option>
                        <option value="Argentina">Argentina</option>
                        <option value="Armenia">Armenia</option>
                        <option value="Aruba">Aruba</option>
                        <option value="Australia">Australia</option>
                        <option value="Austria">Austria</option>
                        <option value="Azerbaijan">Azerbaijan</option>
                        <option value="Bahamas">Bahamas</option>
                        <option value="Bahrain">Bahrain</option>
                        <option value="Bangladesh">Bangladesh</option>
                        <option value="Barbados">Barbados</option>
                        <option value="Belarus">Belarus</option>
                        <option value="Belgium">Belgium</option>
                        <option value="Belize">Belize</option>
                        <option value="Benin">Benin</option>
                        <option value="Bermuda">Bermuda</option>
                        <option value="Bhutan">Bhutan</option>
                        <option value="Bolivia">Bolivia</option>
                        <option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
                        <option value="Botswana">Botswana</option>
                        <option value="Bouvet Island">Bouvet Island</option>
                        <option value="Brazil">Brazil</option>
                        <option value="Brunei">Brunei</option>
                        <option value="Bulgaria">Bulgaria</option>
                        <option value="Burkina Faso">Burkina Faso</option>
                        <option value="Burundi">Burundi</option>
                        <option value="Cambodia">Cambodia</option>
                        <option value="Cameroon">Cameroon</option>
                        <option value="Canada">Canada</option>
                        <option value="Cape Verde">Cape Verde</option>
                        <option value="Cayman Islands">Cayman Islands</option>
                        <option value="Central African Republic">Central African Republic</option>
                        <option value="Chad">Chad</option>
                        <option value="Chile">Chile</option>
                        <option value="China">China</option>
                        <option value="China (Hong Kong S.A.R.)">China (Hong Kong S.A.R.)</option>
                        <option value="China (Macau S.A.R.)">China (Macau S.A.R.)</option>
                        <option value="Christmas Island">Christmas Island</option>
                        <option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands</option>
                        <option value="Colombia">Colombia</option>
                        <option value="Comoros">Comoros</option>
                        <option value="Congo">Congo</option>
                        <option value="Cook Islands">Cook Islands</option>
                        <option value="Costa Rica">Costa Rica</option>
                        <option value="Croatia">Croatia</option>
                        <option value="Cuba">Cuba</option>
                        <option value="Cyprus">Cyprus</option>
                        <option value="Czech Republic">Czech Republic</option>
                        <option value="Denmark">Denmark</option>
                        <option value="Djibouti">Djibouti</option>
                        <option value="Dominica">Dominica</option>
                        <option value="Dominican Republic">Dominican Republic</option>
                        <option value="East Timor">East Timor</option>
                        <option value="Ecuador">Ecuador</option>
                        <option value="Egypt">Egypt</option>
                        <option value="El Salvador">El Salvador</option>
                        <option value="Equatorial Guinea">Equatorial Guinea</option>
                        <option value="Eritrea">Eritrea</option>
                        <option value="Estonia">Estonia</option>
                        <option value="Ethiopia">Ethiopia</option>
                        <option value="Faroe Islands">Faroe Islands</option>
                        <option value="Fiji Islands">Fiji Islands</option>
                        <option value="Finland">Finland</option>
                        <option value="France">France</option>
                        <option value="French Guiana">French Guiana</option>
                        <option value="French Polynesia">French Polynesia</option>
                        <option value="Gabon">Gabon</option>
                        <option value="Gambia">Gambia</option>
                        <option value="Georgia">Georgia</option>
                        <option value="Germany">Germany</option>
                        <option value="Ghana">Ghana</option>
                        <option value="Gibraltar">Gibraltar</option>
                        <option value="Greece">Greece</option>
                        <option value="Greenland">Greenland</option>
                        <option value="Grenada">Grenada</option>
                        <option value="Guadeloupe">Guadeloupe</option>
                        <option value="Guam">Guam</option>
                        <option value="Guatemala">Guatemala</option>
                        <option value="Guinea">Guinea</option>
                        <option value="Guinea-Bissau">Guinea-Bissau</option>
                        <option value="Guyana">Guyana</option>
                        <option value="Haiti">Haiti</option>
                        <option value="Honduras">Honduras</option>
                        <option value="Hungary">Hungary</option>
                        <option value="Iceland">Iceland</option>
                        <option value="India" selected="selected">India</option>
                        <option value="Indonesia">Indonesia</option>
                        <option value="Iran">Iran</option>
                        <option value="Iraq">Iraq</option>
                        <option value="Ireland">Ireland</option>
                        <option value="Israel">Israel</option>
                        <option value="Italy">Italy</option>
                        <option value="Jamaica">Jamaica</option>
                        <option value="Japan">Japan</option>
                        <option value="Jordan">Jordan</option>
                        <option value="Kazakhstan">Kazakhstan</option>
                        <option value="Kenya">Kenya</option>
                        <option value="Kiribati">Kiribati</option>
                        <option value="Korea">Korea</option>
                        <option value="Korea, North">Korea, North</option>
                        <option value="Kuwait">Kuwait</option>
                        <option value="Kyrgyzstan">Kyrgyzstan</option>
                        <option value="Laos">Laos</option>
                        <option value="Latvia">Latvia</option>
                        <option value="Lebanon">Lebanon</option>
                        <option value="Lesotho">Lesotho</option>
                        <option value="Liberia">Liberia</option>
                        <option value="Libya">Libya</option>
                        <option value="Liechtenstein">Liechtenstein</option>
                        <option value="Lithuania">Lithuania</option>
                        <option value="Luxembourg">Luxembourg</option>
                        <option value="Madagascar">Madagascar</option>
                        <option value="Malawi">Malawi</option>
                        <option value="Malaysia">Malaysia</option>
                        <option value="Maldives">Maldives</option>
                        <option value="Mali">Mali</option>
                        <option value="Malta">Malta</option>
                        <option value="Marshall Islands">Marshall Islands</option>
                        <option value="Martinique">Martinique</option>
                        <option value="Mauritania">Mauritania</option>
                        <option value="Mauritius">Mauritius</option>
                        <option value="Mayotte">Mayotte</option>
                        <option value="Mexico">Mexico</option>
                        <option value="Micronesia">Micronesia</option>
                        <option value="Moldova">Moldova</option>
                        <option value="Monaco">Monaco</option>
                        <option value="Mongolia">Mongolia</option>
                        <option value="Montserrat">Montserrat</option>
                        <option value="Morocco">Morocco</option>
                        <option value="Mozambique">Mozambique</option>
                        <option value="Myanmar">Myanmar</option>
                        <option value="Namibia">Namibia</option>
                        <option value="Nauru">Nauru</option>
                        <option value="Nepal">Nepal</option>
                        <option value="Netherlands Antilles">Netherlands Antilles</option>
                        <option value="Netherlands">Netherlands</option>
                        <option value="New Caledonia">New Caledonia</option>
                        <option value="New Zealand">New Zealand</option>
                        <option value="Nicaragua">Nicaragua</option>
                        <option value="Niger">Niger</option>
                        <option value="Nigeria">Nigeria</option>
                        <option value="Niue">Niue</option>
                        <option value="Norfolk Island">Norfolk Island</option>
                        <option value="Northern Mariana Islands">Northern Mariana Islands</option>
                        <option value="Norway">Norway</option>
                        <option value="Oman">Oman</option>
                        <option value="Pakistan">Pakistan</option>
                        <option value="Palau">Palau</option>
                        <option value="Panama">Panama</option>
                        <option value="Papua new Guinea">Papua new Guinea</option>
                        <option value="Paraguay">Paraguay</option>
                        <option value="Peru">Peru</option>
                        <option value="Philippines">Philippines</option>
                        <option value="Pitcairn Island">Pitcairn Island</option>
                        <option value="Poland">Poland</option>
                        <option value="Portugal">Portugal</option>
                        <option value="Puerto Rico">Puerto Rico</option>
                        <option value="Qatar">Qatar</option>
                        <option value="Reunion">Reunion</option>
                        <option value="Romania">Romania</option>
                        <option value="Russia">Russia</option>
                        <option value="Rwanda">Rwanda</option>
                        <option value="Saint Helena">Saint Helena</option>
                        <option value="Saint Lucia">Saint Lucia</option>
                        <option value="Samoa">Samoa</option>
                        <option value="San Marino">San Marino</option>
                        <option value="Sao Tome and Principe">Sao Tome and Principe</option>
                        <option value="Saudi Arabia">Saudi Arabia</option>
                        <option value="Senegal">Senegal</option>
                        <option value="Seychelles">Seychelles</option>
                        <option value="Sierra Leone">Sierra Leone</option>
                        <option value="Singapore">Singapore</option>
                        <option value="Slovakia">Slovakia</option>
                        <option value="Slovenia">Slovenia</option>
                        <option value="Solomon Islands">Solomon Islands</option>
                        <option value="South Africa">South Africa</option>
                        <option value="Spain">Spain</option>
                        <option value="Sri Lanka">Sri Lanka</option>
                        <option value="Sudan">Sudan</option>
                        <option value="Suriname">Suriname</option>
                        <option value="Swaziland">Swaziland</option>
                        <option value="Sweden">Sweden</option>
                        <option value="Switzerland">Switzerland</option>
                        <option value="Syria">Syria</option>
                        <option value="Taiwan">Taiwan</option>
                        <option value="Tajikistan">Tajikistan</option>
                        <option value="Tanzania">Tanzania</option>
                        <option value="Thailand">Thailand</option>
                        <option value="Togo">Togo</option>
                        <option value="Tokelau">Tokelau</option>
                        <option value="Tonga">Tonga</option>
                        <option value="Trinidad And Tobago">Trinidad And Tobago</option>
                        <option value="Tunisia">Tunisia</option>
                        <option value="Turkey">Turkey</option>
                        <option value="Turkmenistan">Turkmenistan</option>
                        <option value="Turks And Caicos Islands">Turks And Caicos Islands</option>
                        <option value="Tuvalu">Tuvalu</option>
                        <option value="Uganda">Uganda</option>
                        <option value="Ukraine">Ukraine</option>
                        <option value="United Arab Emirates">United Arab Emirates</option>
                        <option value="United Kingdom">United Kingdom</option>
                        <option value="United States">United States</option>
                        <option value="Uruguay">Uruguay</option>
                        <option value="Uzbekistan">Uzbekistan</option>
                        <option value="Vanuatu">Vanuatu</option>
                        <option value="Venezuela">Venezuela</option>
                        <option value="Vietnam">Vietnam</option>
                        <option value="Virgin Islands (British)">Virgin Islands (British)</option>
                        <option value="Virgin Islands (US)">Virgin Islands (US)</option>
                        <option value="Western Sahara">Western Sahara</option>
                        <option value="Yemen">Yemen</option>
                        <option value="Yugoslavia">Yugoslavia</option>
                        <option value="Zambia">Zambia</option>
                        <option value="Zimbabwe">Zimbabwe</option>
                    </select>
                </div>
                <div>
                    <label>Web Address</label>
                    <input type="text" class="form-control form-group" name="csite" value="<?php echo $csite; ?>">
                </div>
                    <div>
                    <label>Upload Logo</label>
                    <input type="file" class="form-control form-group" name="clogo" >
                </div>
                    <div>
                    <label>Upload Application</label>
                    <input type="file" class="form-control form-group" name="capp" >
                </div>
                <div>
                    <br/>
                    <input type="submit" class="form-control form-group btn-success" name="submit" value="Update">
                </div>
                </form>
            </div>
            <div class="col-lg-3 ">            
            </div>
        </div>
    
    </body>
</html>