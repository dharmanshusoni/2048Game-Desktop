<?php
if($_SESSION['u1']=="")
{
	
	header("location:index.php");
	
}



?>