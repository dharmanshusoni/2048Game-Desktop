<?php
session_start();

unset($_SESSION['u1']);
session_destroy($_SESSION);
header("location:index.php");


?>