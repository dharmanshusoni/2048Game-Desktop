<?php
//session_start();
//include_once("redirect/redirect.php");
//mysql_connect("localhost","root","") or die("Connection Error");
//mysql_select_db("maritime") or die("Database not found");
//error_reporting(0);
//$_SESSION['u1'];
//
//$pflag=0;
//$query="SELECT * FROM admin WHERE id='".$_GET['id']."'";
//    $result = mysql_query($query);
//$row=mysql_fetch_array($result);
//
//
//if(isset($_POST['Login']))
//{
//    if($_POST['upass']===$_POST['cupass'])
//    {   $pflag=1;}
//    else
//    {
//        echo '<script type="text/javascript">
//                 window.onload = function () { alert("PassWord Do not Match!!!"); }
//                   </script>';
//        
//    }
//    
//    
//     if($pflag=1)
//    {
//         $query="update admin set pass='".$_POST['upass']."' where uname='".$row[1]."'";
//         $rs=mysql_query($query);
//         header("location:admin.php");
//     }
//
//}
?><html>
    <head>
     <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    <!-- Optional theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
        <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
    <title>Admin</title>
    </head>
    <body>
        <?php include_once("../admin/includes/admin_header.php");?> 
    
           <div class="container">
            <div class="col-lg-3"></div>
            <div class="col-lg-6">
                <div class="panel">
			<div class="panel-heading">Update ADMIN LOGIN</div>
			<div class="panel-body">
                <form method="post">
                    <input type="text" name="uname" disabled class="form-control" placeholder="Username" value="<?php echo $row[1];?>" /><br/>
                    <input type="Password" name="upass" required class="form-control" placeholder="New Password"/><br/>
                    <input type="Password" name="cupass" required class="form-control" placeholder="Confirm Password"/><br/>
                    <input type="submit" name="Login" class="form-control btn btn-info" value="Update"/><br/>
                </form>
                </div>
                </div>
            
            </div>
              </div>
    
    </body>

</html>