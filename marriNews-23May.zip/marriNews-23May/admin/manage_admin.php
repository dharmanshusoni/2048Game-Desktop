<?php
session_start();
include_once("redirect/redirect.php");
mysql_connect("localhost","root","") or die("Connection Error");
mysql_select_db("maritime") or die("Database not found");
error_reporting(0);
$_SESSION['u1'];

$query1="SELECT * FROM admin";
 $result1 = mysql_query($query1);

if($_GET['cid']!=null && $_GET['enable']!=null)
{
     $sel="update admin set status='".$_GET['enable']."' where id='".$_GET['cid']."'";
	$rs=mysql_query($sel);
    header("location:manage_admin.php");
}

else if($_GET['did']!=null)
{
     echo $sel="delete from admin where id='".$_GET['did']."'";
	  $rs=mysql_query($sel);	
    header("location:manage_admin.php");
}
?><html>
    <head>
     <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    <!-- Optional theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
        <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
    <title>Admin</title>
    </head>
    <body>
        <?php include_once("../admin/includes/admin_header.php");?> 
    
          <div class="container">
            <center>
        <div class="col-lg-12 table-responsive">
            <h1>Manage Admin</h1>
            <br/>
            <table class="table table-bordered">
                <tr>
                <th bgcolor=#21345><font color="white">Sno.</font></th>
                <th bgcolor=#21345><font color="white">Email</font></th>
                <th bgcolor=#21345><font color="white">Password</font></th>
                <th bgcolor=#21345><font color="white">Edit</font></th>
                    <th bgcolor=#21345><font color="white">Status</font></th>
                    <th bgcolor=#21345><font color="white">Delete</font></th>
            </tr> 
                <?php
                $i=0;
                while($row1=mysql_fetch_array($result1))
                {
                ?>
                <tr>
                    <td align=center><?php echo $i+1; ?></td>
                    <td align=center><?php echo $row1[1]; ?></td>
                    <td align=center><?php echo $row1[2]; ?></td>
                    <td align=center><a href="update_admin.php?id=<?php echo $row1['id'];?>">
                <center><img src="images/edit-notes.png" width="25"></center>
            </a></td>
                    <td align=center><?php
			                 if($row1['status']=='0')
                                {
                                ?>
                                <a href="manage_admin.php?cid=<?php echo $row1['id'];?>&enable=1">
                                    <center>
                                        <img src="images/Off.png" width="30">
                                    </center>              
                                  </a>
                                <?php
                                }
                                else
                                {
                                ?>	
                                <a href="manage_admin.php?cid=<?php echo $row1['id'];?>&enable=0">
                                    <center>
                                        <img src="images/on.png" width="30">
                                    </center>
                                  </a>
                                <?php
                                }
                                ?>	</td>
                    <td align=center><a href="manage_admin.php?did=<?php echo $row1['id'];?>">
                <center><img src="images/Trash-Recyclebin-Empty-Closed.png" width="25"></center>
            </a></td>
                </tr>
                <?php 
                $i++;
                }?>
            </table>
        </div>
            </center>
        </div>
    
    </body>

</html>