 <div class="panel panel-default">
                <div class="panel-body">
                    <a href="About_candidate.php"><input type="button" class="btn btn-block" value="Home"></a>
                    <br/>
                    <a href="Update_profile_candidate.php"><input type="button" class="btn btn-block" value="Update Profile"></a>
                    <br/>
                    <a href="View_job.php"><input type="button" class="btn btn-block" value="View Job"></a>
                    <br/>
                    <input type="submit" class="btn btn-danger btn-block" value="Logout"> 
                    </div>
                </div>