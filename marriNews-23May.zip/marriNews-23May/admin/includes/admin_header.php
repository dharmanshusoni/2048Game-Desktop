<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="admin.php">Mari Time Placement</a>
    </div>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="admin.php">Home</a></li>
      <li><a href="candidate.php">Candidate</a></li>
      <li><a href="company.php">Company</a></li>
      <li><a href="display_job.php">Jobs</a></li>
      <li><a href="news.php">News</a></li>
      <li><a href="create_admin.php">Create Admin</a></li>
      <li><a href="manage_admin.php">Manage Admins</a></li>
      <li><a href="logout.php">Logout</a></li>
    </ul>
  </div>
</nav>
        <h1 align="center">Welcome <?php echo $_SESSION['u1']; ?></h1>