<?php
session_start();
include_once("redirect/redirect.php");
mysql_connect("localhost","root","") or die("Connection Error");
mysql_select_db("maritime") or die("Database not found");
//error_reporting(0);
$_SESSION['u1'];



?>
<html>
    <head>
     <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    <!-- Optional theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
        <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
    <title>Admin</title>
    </head>
    <body>
        <?php include_once("../admin/includes/admin_header.php");?> 
    <div class="col-lg-6" style="padding:5% 7% 5% 10%;"><a href="candidate.php"><img src="images/Candidate.png" class="img-responsive"></a>
                  <div><a href="candidate.php"><h1 align=center>Candidate Details</h1></a></div>
              </div>
              <div class="col-lg-6" style="padding:5% 10% 5% 7%;"><a href="Company.php"><img src="images/company.png" class="img-responsive"></a>
                  <div><a href="Company.php"><h1 align=center>Company Details</h1></a></div>
              </div>
    
    </body>

</html>