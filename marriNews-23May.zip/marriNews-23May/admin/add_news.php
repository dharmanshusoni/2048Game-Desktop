<?php
session_start();
include_once("redirect/redirect.php");
mysql_connect("localhost","root","") or die("Connection Error");
mysql_select_db("maritime") or die("Database not found");
//error_reporting(0);
$_SESSION['u1'];

if(isset($_POST['submit']))
{
    
        $imagename=$_FILES['img1']['name'];
        $imagesize=$_FILES['img1']['size'];
        $imagetype=$_FILES['img1']['type'];
        $imagetmppath=$_FILES['img1']['tmp_name'];
        $imagenewsize=$imagesize/1024;
        $imageext=substr($imagename,-4);
        $rno=rand(999,9999);
        $newimagename=$rno.$imagename;
        $imagepathlogo1="../images/news/".$newimagename;
    $imagepathlogo="images/news/".$newimagename;
     move_uploaded_file($imagetmppath,$imagepathlogo1);

echo $query="insert into news set heading='".$_POST['head']."',
                            descr='".$_POST['descr']."',
                            img='".$imagepathlogo."'";
        
        $rs=mysql_query($query);
   
}

?>

<html>
    <head>
     <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    <!-- Optional theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
        <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
    <title>Admin</title>
    </head>
    <body>
        <?php include_once("../admin/includes/admin_header.php");?> 
    
           <div class="container">
            <div class="col-lg-3"></div>
            <div class="col-lg-6">
                <div class="panel">
                    <div class="panel-heading"><h2 style="font-family:raleway;">Add News</h2></div>
			<div class="panel-body">
                <form enctype="multipart/form-data" method="post">    
                    <label>News Heading</label>
                    <input type="text" required name="head" class="form-control"><br>
                    <label>Description</label>
                    <textarea class="form-control" required name="descr"></textarea><br>
                    <input type="file" name="img1" required class="form-control"><br>
                    <input type="submit" name="submit" class="form-control btn btn-info" value="Submit"/><br/>
                    
                </form>
                </div>
                </div>
            
            </div>
              </div>
    
    </body>

</html>