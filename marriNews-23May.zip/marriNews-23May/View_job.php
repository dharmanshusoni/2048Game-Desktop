<?php
session_start();
mysql_connect("localhost","root","") or die("Connection Error");
mysql_select_db("maritime") or die("Database not found");
error_reporting(0);
echo $query1="SELECT * FROM jobs where dept='".$_GET['d']."' and rank='".$_GET['r']."' and ship='".$_GET['s']."' and status=1";
$result1 = mysql_query($query1);
if(isset($_GET['search']))
{
    if($_GET['ss']===1)
        header("location:view_job.php?v=".$_GET['ss']."&d=".$_GET['dept']."&r=".$_GET['rank']."&s=".$_GET['ship']."");   
    else
        header("location:view_cv.php?v=".$_GET['ss']."&d=".$_GET['dept']."&r=".$_GET['rank']."&s=".$_GET['ship']."");   
}

if(isset($_GET['apply']))
{
 header("location:login.php");   
}

?>

<html>
    <head>
        <title>Company name</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    <!-- Optional theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
        <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="CSS/style.css"/>

    
    </head>
    <body>
        
        <div class="container-fluid">
        <?php include_once("includes/header.php");?>
        <div class="container ">
            <?php include_once("includes/leftpanel.php");?>
            </div>
            <div class="col-lg-6">
                <div class="panel">
			<div class="panel-heading">Recent Entered Jobs</div>
			<div class="panel-body">
                <table class="table table-hover table-striped">
                    <tr>
                                <th align="center">Rank</th>
                                <th align="center">Ship</th>
                                <th align="center">No. of Vacancy</th>
                                <th align="center">Last Date to Apply</th>
                        <th align="center">View</th>
                                <th align="center">Apply</th>
                            </tr>
                            <?php
                            while($row1=mysql_fetch_array($result1))
                            {
                            ?>
                            <tr>
                                <td align="center"><?php echo $row1[2]; ?></td>
                                <td align="center"><?php echo $row1[3]; ?></td>
                                <td align="center"><?php echo $row1[4]; ?></td>
                                <td align="center"><?php echo $row1[5]; ?></td>
                                 <td align="center"><a href="job.php?id=<?php echo $row1[0]; ?>">View</a></td>
                               <td align="center"><form><input type="submit" class="btn btn-primary" value="Apply" name="apply" ></form> </td>                               
                            </tr>
                            
                            <?php
                            }
                            
                            ?>
                </table>
            </div>
                </div>
            </div>
            <div class="col-lg-3">
                
                
            </div>

        </div>
        <?php include_once("includes/footer.php");?>
    </body>
</html>