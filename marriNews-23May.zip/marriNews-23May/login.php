<?php
session_start();
error_reporting(0);
mysql_connect("localhost","root","") or die("Connection Error");
mysql_select_db("maritime") or die("Database not found");

if(isset($_POST['Login']))
{
    if($_POST['op']=='Company')
    {
        $query="SELECT * FROM companylog WHERE cemail='".$_POST['email']."'";
        $result = mysql_query($query);
        $num_rows = mysql_num_rows($result);
        if($num_rows)
        {
            $row=mysql_fetch_array($result);
            if($_POST['pass']===$row[2])
            {
                $_SESSION['u']=$_POST['email'];
                header("location:company_home.php");
            }
            else
            {echo '<script type="text/javascript">
                window.onload = function () { alert("Invalid UserName or Password!!!"); }
                    </script>';}
        }
        else
        {echo '<script type="text/javascript">
                window.onload = function () { alert("Invalid UserName or Password!!!"); }
                    </script>';}
    }
    else
    {
        if($_POST['op']=='Candidate')
        {
             $query="SELECT * FROM candidatelog WHERE canemail='".$_POST['email']."'";
            $result = mysql_query($query);
            $num_rows = mysql_num_rows($result);
            if($num_rows)
            {
                $row=mysql_fetch_array($result);
                if($_POST['pass']===$row[2])
                {
                $_SESSION['u']=$_POST['email'];
                header("location:about_candidate.php");
                }
                else
                {echo '<script type="text/javascript">
                window.onload = function () { alert("Invalid UserName or Password!!!"); }
                    </script>';}
            }
            else
            {echo '<script type="text/javascript">
                window.onload = function () { alert("Invalid UserName or Password!!!"); }
                    </script>';}
        }
    }
}

?>
<html>
    <head>
        <title>Mari Time Placement | Login</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    <!-- Optional theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
        <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="CSS/style.css"/>

    
    </head>
    <body>
        
          <div class="container-fluid">
             <?php include_once("includes/header.php");?>
        <div class="container">
            <div class="col-lg-3"></div>
            <div class="col-lg-6">
                <div class="panel">
			<div class="panel-heading" style="color: #213458;"><h4><b>LOGIN HERE</b></h4></div>
			<div class="panel-body">
                <form method="post">
                    <input type="email" name="email" class="form-control" required placeholder="Email"/><br/>
                    <select class="form-control form-group" name="op" required>
                        <option>-- Select --</option>
                        <option>Company</option>
                        <option>Candidate</option>
                    </select>
                    <input type="Password" name="pass" class="form-control"  required placeholder="Password"/><br/>
                    <input type="submit" name="Login" class="form-control btn" value="Login"/><br/>
                    <br/>
                    <a href="register.php"><input type="button" Value="!! Register Here !!" class="btn btn-warning form-control form-group"></a> 
                </form>
                </div>
                </div>
            
            </div>
              </div>
        </div>
        <?php include_once("includes/footer.php");?>
    </body>
</html>