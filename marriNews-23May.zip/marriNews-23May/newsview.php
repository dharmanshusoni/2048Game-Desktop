<?php
session_start();
mysql_connect("localhost","root","") or die("Connection Error");
mysql_select_db("maritime") or die("Database not found");
error_reporting(0);


$query="SELECT * FROM news WHERE id='".$_GET['id']."'";
$result = mysql_query($query);
$row=mysql_fetch_array($result);

$query1="SELECT * FROM news";
$result1 = mysql_query($query1);


?>

<html>
    <head>
        <title>Maritime | NewsView</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    <!-- Optional theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
        <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="CSS/style.css"/>
        
    </head>
    <body>
        
    <div class="container-fluid">
        <?php include_once("includes/header.php");?>
            </div>
        <br>
      <div class="container">
          <div class="col-lg-12">
            <div class="col-lg-8"><img src="<?php echo $row[3]; ?>" height=400 width=700>
                <div><h1>Heading</h1>
                    <hr style="width: 100%; color: black; height: 1px; background-color:black;" /> 
                </div>
                <p class="text"><?php echo $row[1]; ?></p>
              
                <div><h1>Description</h1>
                    <hr style="width: 100%; color: black; height: 1px; background-color:black;" /> 
                </div>
                <p class="text"><?php echo $row[2]; ?></p>
              </div>
              
              
            
              <div class="col-lg-4 well"><h3>News</h3>
                  <hr style="width: 100%; color: black; height: 1px; background-color:black;" /> 
                  <marquee direction="up" loop=infinite onmouseover="this.stop();" onmouseout="this.start();">
                      <?php while($row1=mysql_fetch_array($result1))
                            {
                      ?>
                      <a href="newsview.php?id=<?php echo $row1[0]; ?>"><?php echo $row1[1]; ?></a>
                      <br>
                      <br>
                      <br>
                      <?php 
                            }
                      ?></marquee>
              </div>
          </div>  
        </div>
            

        <?php include_once("includes/footer.php");?>
    </body>
</html>