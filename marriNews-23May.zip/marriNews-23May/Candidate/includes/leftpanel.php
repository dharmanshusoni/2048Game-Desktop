<div class="col-lg-3 ">
            <div class="panel">
			<div class="panel-heading">SEARCH</div>
			<div class="panel-body">
                <form>
                    <select class="form-control form-group">
                        <option>-- Department --</option>
                        <option>Offshore</option>
                        <option>Deck</option>
                        <option>Engine</option>
                        <option>Catering</option>
                        <option>Safety / Security / Medical</option>
                        <option>Cruiser Staff</option>
                        <option>Platform</option>
                        <option>Shore</option>
                    </select>
                    <select class="form-control form-group">
                            <option>-- Ships --</option>
                            <option value="Bulk Carrier">Bulk Carrier</option>
                            <option value="Car Carrier">Car Carrier</option>
                           <option value="Oil Tanker">Oil Tanker</option>
                           <option value="Chemical Tanker">Chemical Tanker</option>
                           <option value="VLCC">VLCC</option>
                           <option value="LPG Carrier">LPG Carrier</option>
                           <option value="Container">Container</option>
                           <option value="Dry Cargo">Dry Cargo</option>
                           <option value="Reefer">Reefer</option>
                           <option value="Reefer container">Reefer container</option>
                           <option value="RORO">RORO</option>
                           <option value="OBO">OBO</option>
                           <option value="Multi-Purpose Vessel">Multi-Purpose Vessel</option>
                           <option value="Cruise Ship">Cruise Ship</option>
                           <option value="Offshore Vessel ">Offshore Vessel </option>
                           <option value="Coastal Vessel ">Coastal Vessel </option>
                           <option value="TUG ">TUG </option>
                           <option value="Dredger">Dredger</option>
                           <option value="General Cargo ">General Cargo </option>
                           <option value="Product Tanker ">Product Tanker </option>
                           <option value="Survey Vessel ">Survey Vessel </option>
                           <option value="Wood/Log Carrier ">Wood/Log Carrier </option>
                           <option value="Fishing Vessel ">Fishing Vessel </option>
                           <option value="LNG Carrier">LNG Carrier</option>
                           <option value="Aframax Tanker">Aframax Tanker</option>
                           <option value="Crude Oil Tanker">Crude Oil Tanker</option>
                           <option value="D P Vessel">D P Vessel</option>
                           <option value="FPSO">FPSO</option>
                    </select>
                    <select class="form-control form-group">
                        <option>-- Ranks --</option>
                          <option value="Master">Master</option>
                          <option value="C/O">Chief Officer</option>
                          <option value="2/O">2nd Officer</option>
                          <option value="3/O">3rd Officer</option>
                          <option value="R/O">Radio Officer </option>
                          <option value="Dck/Cdt">Deck Cadet </option>
                          <option value="Tr/Cdt">Trainee Cadet </option>
                          <option value="Bosun">Bosun </option>
                          <option value="Dck/Ftr">Deck Fitter </option>
                          <option value="AB">AB </option>
                          <option value="OS">OS </option>
                          <option value="GP">GP </option>
                          <option value="Cr/Optr">Crane Operator </option>
                          <option value="Jr/O">Junior Officer</option>
                          <option value="Pumpman">Pumpman</option>
                          <option value="Fitters,Oilers">Fitters, Oilers</option>
                          <option value="Fitter">Fitter</option>
                          <option value="C/E">Chief Engineer </option>
                          <option value="2/E">2nd Engineer </option>
                          <option value="3/E">3rd Engineer </option>
                          <option value="4/E">4th Engineer </option>
                          <option value="5/E">5th Engineer </option>
                          <option value="E/E">Electrical Engineer</option>
                          <option value="E/O">Electrical Officer </option>
                          <option value="ETO">Electro Technical Officer</option>
                          <option value="Jr/E">Junior Engineer</option>
                          <option value="Asst.E/O">Asst. Electrical Officer</option>
                          <option value="Tr/E">Trainee Engineer </option>
                          <option value="R/E">Reefer Engineer </option>
                          <option value="R/Mech">Reefer Mechanic </option>
                          <option value="G/E">Gas Engineer</option>
                          <option value="E/F">Engine Fitter </option>
                          <option value="Motorman">Motorman </option>
                          <option value="Wiper">Wiper </option>
                          <option value="Trvl/Ftr">Travel Fitter </option>
                          <option value="Trvl/Wiper">Travel Wiper </option>
                          <option value="Pielstik/Engineer">Pielstik Engineer</option>
                          <option value="Htl/Mgr">Hotel Manager</option>
                          <option value="Purser">Purser </option>
                          <option value="Scl/Dir">Social Director </option>
                          <option value="Sprt/Dir">Sports Director </option>
                          <option value="Chef">Chef </option>
                          <option value="S/Chef">Souse Chef </option>
                          <option value="Ch/Cook">Chief Cook </option>
                          <option value="2/Cook">2nd Cook </option>
                          <option value="Ch/Stwd">Chief Steward </option>
                          <option value="Stwd">Steward </option>
                          <option value="Cabin/Attd">Cabin Attendant </option>
                          <option value="Bar/Tdr">Bar Tender </option>
                          <option value="Musician">Musician </option>
                          <option value="Lndr/Men">Laundry Men </option>
                          <option value="Security/Guard">Security Guard</option>
                          <option value="S.O.">Safety Officer</option>
                    </select>
                    &nbsp;
                    &nbsp;
                    &nbsp;
                    
                    <input type="radio" name="" class="form-group">JOB
                    &nbsp;
                    &nbsp;
                    &nbsp;
                    &nbsp;
                    &nbsp;
                    &nbsp;
                    &nbsp;
                    <input type="radio" name="ss" class="form-group">CV
                    <br>
                    <br>
                    
                    <input type="submit" name="ss" Value="Search" class="btn form-control form-group">
                </form>
                </div>
                </div>
