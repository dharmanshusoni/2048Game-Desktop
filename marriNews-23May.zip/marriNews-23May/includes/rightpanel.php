 <div class="panel panel-default">
                <div class="panel-body">
                    <a href="company_home.php"><input type="button" class="btn btn-block" value="Home"></a>
                    <br/>
                    <a href="post_job.php"><input type="button" class="btn btn-block" value="Post Job"></a>
                    <br/>
                    <a href="company_update.php"><input type="button" class="btn btn-block" value="Update Profile"></a>
                    <br/>
                     <a href="view_cvC.php"><input type="button" class="btn btn-block" value="View Candidates"></a>
                    <br/>
                    <a href="logout.php">
                    <input type="button" class="btn btn-danger btn-block" value="Logout"> </a>
                    </div>
                </div>