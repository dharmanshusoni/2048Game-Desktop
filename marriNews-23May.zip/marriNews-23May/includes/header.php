<nav class="navbar navbar-inverse container-fluid" style="width: 90%">
  <div class="container-fluid" >
    <div class="navbar-header">
      <a class="navbar-brand" href="index.php">Mari Time Placement</a>
    </div>
    <ul class="nav navbar-nav navbar-right">
      <li ><a href="index.php">Home</a></li>
      <li><a href="candidate_login.php">Post Resume</a></li>
      <li><a href="company_login.php">Post Job</a></li>
      <li><a href="news.php">News</a></li>
      <li><a href="login.php">Login</a></li>
    </ul>
  </div>
</nav>
<br/>