<div class="col-sm-3">
      <div class="panel" style="box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);color: #213458;">
			   <div class="panel-heading" ><h4><b>Navigation</b></h4></div>
			   <div class="panel-body" >
                <ul style="list-style-type: circle;padding-left: 20px;">
                    <li style="margin-top: 5px; "><a href="https://www.world-airport-codes.com/">       World Airport Code </a></li>
                    <li style="margin-top: 5px; "><a href="http://www.worldtravelguide.net/">           World Travel Guide </a></li>
                    <li style="margin-top: 5px; "><a href="http://www.flightstats.com/go/Home/home.do"> Flight Stats       </a></li>
                    <li style="margin-top: 5px; "><a href="http://passportindia.gov.in/AppOnlineProject/online/procFormSubOnl"> Passport Form      </a></li>
                    <li style="margin-top: 5px; "><a href="https://travel.state.gov/content/visas/en.html"> Visa Form      </a></li>
                    <li style="margin-top: 5px; "><a href="http://www.xe.com/currencyconverter/">       Currency Converter </a></li>
                </ul>
           </div>
      </div>

      <div class="panel" style="box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);color: #213458;">
         <div class="panel-heading" ><h4><b>Latest News</b></h4></div>
         <div class="panel-body" >
                <ul style="list-style-type: circle;padding-left: 20px;">
                    <li style="margin-top: 5px; "><a href="https://www.world-airport-codes.com/">       World Airport Code </a></li>
                    <li style="margin-top: 5px; "><a href="http://www.worldtravelguide.net/">           World Travel Guide </a></li>
                    <li style="margin-top: 5px; "><a href="http://www.flightstats.com/go/Home/home.do"> Flight Stats       </a></li>
                    <li style="margin-top: 5px; "><a href="http://passportindia.gov.in/AppOnlineProject/online/procFormSubOnl"> Passport Form      </a></li>
                    <li style="margin-top: 5px; "><a href="https://travel.state.gov/content/visas/en.html"> Visa Form      </a></li>
                    <li style="margin-top: 5px; "><a href="http://www.xe.com/currencyconverter/">       Currency Converter </a></li>
                </ul>
           </div>
      </div>

      <div class="panel" style="box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);color: #213458;">
         <div class="panel-heading" ><h4><b>Upload your CV</b></h4></div>
         <div class="panel-body" >
              Increase your chances of being selected<br><br>
              <form action="candidate_login.php">
                <input type="submit" class="btn btn-primary btn-lg" value="Submit your CV" />
              </form>
           </div>
      </div>
</div>
