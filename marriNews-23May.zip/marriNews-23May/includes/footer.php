    <div class="container-fluid" style="background-color: #213458;">
        <div class="row" style="color: #9FA8DA;"> 
            <div class="col-sm-3">
                <h3 style="padding-left: 30px;" >QUICK LINKS</h3>   
                <ul style="list-style-type: circle;padding-left: 50px;">
                    <li>Home</li>
                    <li>About</li>
                    <li>Articles</li>
                    <li>Information</li>
                </ul>
            </div>

            <div class="col-sm-3">
                <h3 ">USEFULL LINKS</h3>  
                <ul style="list-style-type: circle;padding-left: 20px;">
                    <li>Passport</li>
                    <li>Visa</li>
                    <li>News</li>
                    <li>Search</li> 
                </ul>
            </div>

            <div class="col-sm-3">
                <h3 >SOCIAL LINKS</h3>  
                <ul style="list-style-type: circle;padding-left: 20px;">
                    <li>Facebook</li>
                    <li>LinkedIn</li>
                    <li>Google+</li>
                    <li>Mail</li> 
                </ul> 
            </div>
        
            <div class="col-sm-3" >
                <h3 >CONTACT US</h3>
                <address>
                    <strong>Ratanada</strong><br>
                    office no 121.<br>
                    Jodhpur<br>
                    Rajasthan<br>
                    India<br>
                    <abbr title="Phone">M:</abbr> 01234 567 890
                </address>
            </div>
        </div>
        <div class="row" style="background-color: #131e33;"> 
            <div class="text-center">
                develope by - team
            </div>
        </div> 
    </div>
