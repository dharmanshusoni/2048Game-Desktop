<?php
session_start();
mysql_connect("localhost","root","") or die("Connection Error");
mysql_select_db("maritime") or die("Database not found");
error_reporting(0);

 $query1="select * from news where status=1 order by id desc limit 15";
 $result1 = mysql_query($query1);


?>


<html>
    <head>
        <title>MariTime | NEWS</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    <!-- Optional theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
        <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="CSS/style.css"/>
        
    </head>
    <body>
        
    <div class="container-fluid">
        <?php include_once("includes/header.php");?>
            </div>
      <div class="container">
           <div class="col-lg-12">
               <h4 align="center">Latest News</h4>
               <hr color="green" width="15%" size="10" style="width: 20%; color: black; height: 1px; background-color:black;">
                <?php
                            $i=0;
                            while(($row1=mysql_fetch_array($result1)) && ($i<15))
                            {
                            ?>
                                    <div class="col-lg-4">
                                            <div class="panel panel-default">
                                                    <div class="panel-body"><img src="<?php echo $row1[3]; ?>" width="300" height=200></div>
                                                    <div class="panel-footer"><a href="newsview.php?id=<?php echo $row1[0]; ?>"><?php echo $row1[1]; ?></a></div>
                                            </div>
                                    </div>
               <?php $i++;
               }
               ?>
            </div>

        </div>
        <?php include_once("includes/footer.php");?>
    </body>
</html>