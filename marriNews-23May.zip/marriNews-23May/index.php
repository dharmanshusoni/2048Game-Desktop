<?php
session_start();
mysql_connect("localhost","root","") or die("Connection Error");
mysql_select_db("maritime") or die("Database not found");
error_reporting(0);

 $query1="select * from jobs where status=1 order by id desc limit 5";
$result1 = mysql_query($query1);

 $query12="SELECT * FROM candidate where status=1 order by id desc limit 5";
 $result12 = mysql_query($query12);


$querycimg="SELECT * FROM company where status=1";
$resultc1 = mysql_query($querycimg);
$num_rows = mysql_num_rows($resultc1);

$k=0;
while($resultc2=mysql_fetch_array($resultc1))
{
    $resultcimg[$k] = $resultc2;
    $k++;   
}

if(isset($_GET['search']))
{
    if($_GET['ss']==1)
        header("location:view_job.php?v=".$_GET['ss']."&d=".$_GET['dept']."&r=".$_GET['rank']."&s=".$_GET['ship']."");   
    else
        header("location:view_cv.php?v=".$_GET['ss']."&d=".$_GET['dept']."&r=".$_GET['rank']."&s=".$_GET['ship']."");   
}

if(isset($_GET['apply']))
{
 header("location:login.php");   
}
?>

<html>
    <head>
        <title>Company name</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    <!-- Optional theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
        <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="CSS/style.css"/>
        
    </head>
    <body>
        
    <div class="container-fluid">
        <?php include_once("includes/header.php");?>
        <div class="container ">
            <?php include_once("includes/leftpanel.php");?>
            </div>
            <div class="col-lg-6">
            <div class="panel">
			     <div class="panel-heading" style="color: #213458;"><h4>Recent Entered Jobs</h4></div>
			         <div class="panel-body">
                        <table class="table table-hover table-striped">
                            <tr>
                                <th align="center">Rank</th>
                                <th align="center">Ship</th>
                                <th align="center">No. of Vacancy</th>
                                <th align="center">Last Date to Apply</th>
                                <th align="center">View</th>
                                <th align="center">Apply</th>
                            </tr>
                            <?php
                            $i=0;
                            while(($row1=mysql_fetch_array($result1)) && ($i<5))
                            {
                            ?>
                            <tr>
                                <td align="center"><?php echo $row1[2]; ?></td>
                                <td align="center"><?php echo $row1[3]; ?></td>
                                <td align="center"><?php echo $row1[4]; ?></td>
                                <td align="center"><?php echo $row1[5]; ?></td>
                                <td align="center"><a href="job.php?id=<?php echo $row1[0]; ?>">View</a></td>
                                <td align="center"><form><input type="submit" class="btn btn-primary" value="Apply" name="apply" ></form> </td> 
                            </tr>
                            
                            <?php
                           $i++; }
                            
                            ?>
                        </table>
                        <hr>                
                    </div>
            </div>
            <div class="panel">
                <div class="panel-heading" style="color: #213458;"><h4>Recent uploaded resume</h4></div>
                <div class="panel-body">
                        <table class="table table-hover table-striped">
                                  <tr>
                                <th>Sno.</th>       
                                <th>Candidate Name</th>
                                <th>Rank</th>
                                <th>Ship</th>
                                <th>View Profile</th>
                            </tr>
                            <?php
                            $i=0;
                            while(($row12=mysql_fetch_array($result12) ) && ($i < 5))
                            {
                            ?>
                            <tr>
                                <td><?php echo $i+1;?></td>      
                                <td><?php echo $row12[1];?></td>
                                <td><?php echo $row12[9];?></td>
                                <td><?php echo $row12[10];?></td>
                                <td><a href="view_profile.php?id=<?php echo $row12[0]; ?>" >View Profile</a></td>
                            </tr>
                            <?php
                            $i++;}
                            ?>
                    </table>
                </div>
            </div>
                <div>
                    <div class="panel">
                        <div class="panel-heading" style="color: #213458;"><h4>Featured Companies</h4></div>
                <div class="panel-body">
                    <?php
                    $i=0;
                    $j=0;
                    $flag=0;
                    $dispnum=rand(0,$num_rows);
                    $used[$j]=$dispnum;
                    $j++;
                    $dispnum=rand(0,$num_rows);
                    while($j<12 && $j<$num_rows)
                    {
                        for($c=0;$c<$j;$c++)
                        {
                            if($used[$c]===$dispnum)
                            {   
                                $flag=1;
                                break;
                            }            
                        }
                        
                         if($flag!==1)
                            {
                               $used[$j]=$dispnum;
                                 $j++;
                            }
                        $dispnum=rand(0,$num_rows);
                        $flag=0;
                    }           
                    while($i<$j)
                    { 
                    ?>
                    <a href="job.php?cid=<?php echo $resultcimg[$i][0]; ?>">
                    <div class="borderimg thumbnail" style=" height:76px; width:24%; background-size:contain ; float:left;  background-repeat: no-repeat;">        
                        <img style="max-height:100%;" class="img-responsive" src="<?php echo $resultcimg[$i][11];?>" >
                    </div>      
                    </a>              
                    <div style="float:left;">&nbsp;</div>
                    
                    <?php
                    $i++;
                    }?>                    
                    
                        </div>
                    </div>
    
                    
                </div>
            
            </div>

            <div class="container ">
                <?php include_once("includes/rightpanelTheme.php");?>
            </div>

        </div>
        <?php include_once("includes/footer.php");?>
    </body>
</html>