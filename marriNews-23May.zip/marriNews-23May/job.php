<?php
session_start();
mysql_connect("localhost","root","") or die("Connection Error");
mysql_select_db("maritime") or die("Database not found");
error_reporting(0);


if(isset($_GET['search']))
{
    if($_GET['ss']===1)
        header("location:view_job.php?v=".$_GET['ss']."&d=".$_GET['dept']."&r=".$_GET['rank']."&s=".$_GET['ship']."");   
    else
        header("location:view_cv.php?v=".$_GET['ss']."&d=".$_GET['dept']."&r=".$_GET['rank']."&s=".$_GET['ship']."");   
}

if(isset($_GET['apply']))
{
 header("location:login.php");   
}

if($_GET['cid'])
{
     $query="SELECT * FROM company WHERE id='".$_GET['cid']."' and status=1";
            $result = mysql_query($query);
     $row=mysql_fetch_array($result);
    
    $query1="SELECT * FROM jobs WHERE cemail='".$row[3]."' and status=1";
            $result1 = mysql_query($query1);
    
    
}

else
{
    $query="SELECT cemail FROM jobs WHERE id='".$_GET['id']."'";
            $result = mysql_query($query);
            $row2=mysql_fetch_array($result);


 $query="SELECT * FROM company WHERE email='".$row2[0]."'";
            $result = mysql_query($query);
            $row=mysql_fetch_array($result);

 $query1="SELECT * FROM jobs WHERE cemail='".$row2[0]."' and status=1";
            $result1 = mysql_query($query1);
}



?>
<html>
    <head>
        <title>Company Login</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    <!-- Optional theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
        <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="CSS/style.css"/>

    
    </head>
    <body>
        
          <div class="container-fluid">
             <?php include_once("includes/header.php");?>
        </div>
        <div class="container">
            <?php include_once("includes/leftpanel.php");?>
            </div>
            <div class="col-lg-6">
                <form>
                    <div>
                        <table class="table table-bordered table-responsive">
                            <tr>
                                <td colspan="4" align="center">Company Details</td>
                            </tr>
                            <tr>
                                <td><img src="<?php echo $row[11]; ?>" class="img-responsive"></td>       
                                <td colspan="3"><?php echo $row[1]; ?></td>
                            </tr>
                            <tr>
                                <td>Contact Person</td>
                                <td><?php echo $row[2]; ?></td>
                                <td>Email id</td>
                                <td><?php echo $row[3]; ?></td>
                            </tr>
                            <tr>
                                <td>Contact No</td>
                                <td><?php echo $row[4]; ?></td>
                                <td>Fax</td>
                                <td><?php echo $row[5]; ?></td>
                            </tr>
                            <tr>
                                <td>Website</td>
                                <td colspan="3"><?php echo $row[10]; ?></td>
                            </tr>
                            <tr>
                                <td>Address</td>
                                <td colspan="3"><?php echo $row[6]; ?></td>
                            </tr>
                            <tr>
                                <td colspan="4" align="center">Posted Job</td>
                            </tr>
                            <tr>
                                <td align="center">Rank</td>
                                <td align="center">Ship</td>
                                <td align="center">No. of Vacancy</td>
                                <td align="center">Last Date to Apply</td>
                            </tr>
                            <?php
                            while($row1=mysql_fetch_array($result1))
                            {
                            ?>
                            <tr>
                                <td align="center"><?php echo $row1[2]; ?></td>
                                <td align="center"><?php echo $row1[3]; ?></td>
                                <td align="center"><?php echo $row1[4]; ?></td>
                                <td align="center"><?php echo $row1[5]; ?></td>
                                <td align="center"><form><input type="submit" class="btn btn-primary" value="Apply" name="apply" ></form> </td> 
                                
                            </tr>
                            
                            <?php
                            }
                            
                            ?>
                            
                        </table>
                    </div>
                </form>
              </div>
            <div class="col-lg-3 ">
                
            </div>
            <?php include_once("includes/footer.php");?>
    </body>
</html>