<?php
if($_SESSION['u']=="")
{
	
	header("location:login.php");
	
}



?>