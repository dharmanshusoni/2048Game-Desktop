<?php
session_start();
include_once("redirect/redirect.php");
mysql_connect("localhost","root","") or die("Connection Error");
mysql_select_db("maritime") or die("Database not found");
error_reporting(0);
$_SESSION['u'];

 $query="SELECT jid FROM japp where canemail='".$_SESSION['u']."'";
            $result = mysql_query($query);
$i=0;
while($row=mysql_fetch_array($result))
{
    $query1="SELECT * FROM jobs where id='".$row[0]."'";
    $result1 = mysql_query($query1);
    $row1=mysql_fetch_array($result1);
    $row11[$i]=$row1;
    $i=$i+1;
}
if(isset($_GET['search']))
{
    if($_GET['ss']===1)
        header("location:view_job.php?v=".$_GET['ss']."&d=".$_GET['dept']."&r=".$_GET['rank']."&s=".$_GET['ship']."");   
    else
        header("location:view_cv.php?v=".$_GET['ss']."&d=".$_GET['dept']."&r=".$_GET['rank']."&s=".$_GET['ship']."");   
}
 $k=0;
    

?>

<html>
    <head>
        <title>Company name</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    <!-- Optional theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
        <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="CSS/style.css"/>

    
    </head>
    <body>
        
        <div class="container-fluid">
        <?php include_once("includes/header.php");?>
        <div class="container ">
            <?php include_once("includes/leftpanel.php");?>
            </div>
            <div class="col-lg-6">
                <div class="panel">
			<div class="panel-heading">Jobs Applied</div>
			<div class="panel-body">
                <table class="table table-hover table-striped">
                            <tr>
                                <td align="center">Rank</td>
                                <td align="center">Ship</td>
                                <td align="center">No. of Vacancy</td>
                                <td align="center">Last Date to Apply</td>
                            </tr>
                    <?php
                            for($k=0;$k<$i;$k++)
                            {
                            ?>
                            <tr>
                                <td align="center"><?php echo $row11[$k][2]; ?></td>
                                <td align="center"><?php echo $row11[$k][3]; ?></td>
                                <td align="center"><?php echo $row11[$k][4]; ?></td>
                                <td align="center"><?php echo $row11[$k][5]; ?></td>
                                
                            </tr>
                            
                            <?php
                            }
                            
                            ?>
                </table>
            </div>
                </div>
            </div>
            <div class="col-lg-3">
                 <?php
                    include_once("candidate/includes/rightpanel.php");
                ?>
                
            </div>

        </div>
        <?php include_once("includes/footer.php");?>
    </body>
</html>