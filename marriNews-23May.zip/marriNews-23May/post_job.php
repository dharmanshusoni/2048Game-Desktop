<?php
session_start();
include_once("redirect/redirect.php");
mysql_connect("localhost","root","") or die("Connection Error");
mysql_select_db("maritime") or die("Database not found");
error_reporting(0);
$_SESSION['u'];

if(isset($_POST['submit']))
{
     $query="insert into jobs set dept='".$_POST['dept']."',
                            rank='".$_POST['rank']."',
                            ship='".$_POST['ship']."',
                            post='".$_POST['post']."',
                            aptill='".$_POST['aptill']."',
                            cemail='".$_SESSION['u']."'";
    $rs=mysql_query($query);
    
    
}
if(isset($_GET['search']))
{
    if($_GET['ss']===1)
        header("location:view_job.php?v=".$_GET['ss']."&d=".$_GET['dept']."&r=".$_GET['rank']."&s=".$_GET['ship']."");   
    else
        header("location:view_cv.php?v=".$_GET['ss']."&d=".$_GET['dept']."&r=".$_GET['rank']."&s=".$_GET['ship']."");   
}

?>
<html>
    <head>
        <title>Company Login</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    <!-- Optional theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
        <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="CSS/style.css"/>

    
    </head>
    <body>
        
          <div class="container-fluid">
             <?php include_once("includes/header.php");?>
        <div class="container ">
            <?php include_once("includes/leftpanel.php");?>
            </div>
            <div class="col-lg-6">
                <form method="post" class="border">
                <h1 align="center">Post Job</h1>
                <div>
                <label>Department</label>
                    <select class="form-control form-group " name="dept" required>
                        <option selected="selected">-- Select Department --</option>
                                <option value="offshore">Offshore</option>
                                <option value="deck">Deck</option>
                                <option value="engine">Engine</option>
                                <option value="catering">Catering</option>
                                <option value="s/s/M">Safety / Security / Medical</option>
                                <option value="c/s">Cruiser Staff </option>
                                <option value="platform">Platform</option>
                                <option value="shore">Shore</option>
                                <option value="other">Other</option>

                    </select>
                </div>
                <div>
                <label>Rank</label>
                    <select class="form-control form-group" name="rank" required >
                         <option value=" " selected="selected">-- Select Ranks -- </option>
                                <option value="Master">Master</option>
                                <option value="C/O">Chief Officer</option>
                                <option value="2/O">2nd Officer</option>
                                <option value="3/O">3rd Officer</option>
                                <option value="R/O">Radio Officer </option>
                                <option value="Dck/Cdt">Deck Cadet </option>
                                <option value="Tr/Cdt">Trainee Cadet </option>
                                <option value="Bosun">Bosun </option>
                                <option value="Dck/Ftr">Deck Fitter </option>
                                <option value="AB">AB </option>
                                <option value="OS">OS </option>
                                <option value="GP">GP </option>
                                <option value="Cr/Optr">Crane Operator </option>
                                <option value="Jr/O">Junior Officer</option>
                                <option value="Pumpman">Pumpman</option>
                                <option value="Fitters,Oilers">Fitters, Oilers</option>
                                <option value="Fitter">Fitter</option>
                                <option value="C/E">Chief Engineer </option>
                                <option value="2/E">2nd Engineer </option>
                                <option value="3/E">3rd Engineer </option>
                                <option value="4/E">4th Engineer </option>
                                <option value="5/E">5th Engineer </option>
                                <option value="E/E">Electrical Engineer</option>
                                <option value="E/O">Electrical Officer </option>
                                <option value="ETO">Electro Technical Officer</option>
                                <option value="Jr/E">Junior Engineer</option>
                                <option value="Asst.E/O">Asst. Electrical Officer</option>
                                <option value="Tr/E">Trainee Engineer </option>
                                <option value="R/E">Reefer Engineer </option>
                                <option value="R/Mech">Reefer Mechanic </option>
                                <option value="G/E">Gas Engineer</option>
                                <option value="E/F">Engine Fitter </option>
                                <option value="Motorman">Motorman </option>
                                <option value="Wiper">Wiper </option>
                                <option value="Trvl/Ftr">Travel Fitter </option>
                                <option value="Trvl/Wiper">Travel Wiper </option>
                                <option value="Pielstik/Engineer">Pielstik Engineer</option>
                                <option value="Htl/Mgr">Hotel Manager</option>
                                <option value="Purser">Purser </option>
                                <option value="Scl/Dir">Social Director </option>
                                <option value="Sprt/Dir">Sports Director </option>
                                <option value="Chef">Chef </option>
                                <option value="S/Chef">Souse Chef </option>
                                <option value="Ch/Cook">Chief Cook </option>
                                <option value="2/Cook">2nd Cook </option>
                                <option value="Ch/Stwd">Chief Steward </option>
                                <option value="Stwd">Steward </option>
                                <option value="Cabin/Attd">Cabin Attendant </option>
                                <option value="Bar/Tdr">Bar Tender </option>
                                <option value="Musician">Musician </option>
                                <option value="Lndr/Men">Laundry Men </option>
                                <option value="Security/Guard">Security Guard</option>
                                <option value="S.O.">Safety Officer</option>
                                <option value="Other ship">Other Ship</option>
                                <option value="Master">Master</option>
                                <option value="C/O">Chief Officer</option>
                                <option value="2/O">2nd Officer</option>
                                <option value="3/O">3rd Officer</option>
                                <option value="R/O">Radio Officer </option>
                                <option value="Dck/Cdt">Deck Cadet </option>
                                <option value="Tr/Cdt">Trainee Cadet </option>
                                <option value="Bosun">Bosun </option>
                                <option value="Dck/Ftr">Deck Fitter </option>
                                <option value="AB">AB </option>
                                <option value="OS">OS </option>
                                <option value="GP">GP </option>
                                <option value="Cr/Optr">Crane Operator </option>
                                <option value="Jr/O">Junior Officer</option>
                                <option value="Pumpman">Pumpman</option>
                                <option value="Fitters,Oilers">Fitters, Oilers</option>
                                <option value="Fitter">Fitter</option>
                                <option value="C/E">Chief Engineer </option>
                                <option value="2/E">2nd Engineer </option>
                                <option value="3/E">3rd Engineer </option>
                                <option value="4/E">4th Engineer </option>
                                <option value="5/E">5th Engineer </option>
                                <option value="E/E">Electrical Engineer</option>
                                <option value="E/O">Electrical Officer </option>
                                <option value="ETO">Electro Technical Officer</option>
                                <option value="Jr/E">Junior Engineer</option>
                                <option value="Asst.E/O">Asst. Electrical Officer</option>
                                <option value="Tr/E">Trainee Engineer </option>
                                <option value="R/E">Reefer Engineer </option>
                                <option value="Reefer Mechanic ">Reefer Mechanic </option>
                                <option value="G/E">Gas Engineer</option>
                                <option value="E/F">Engine Fitter </option>
                                <option value="Motorman">Motorman </option>
                                <option value="Wiper">Wiper </option>
                                <option value="Trvl/Ftr">Travel Fitter </option>
                                <option value="Trvl/Wiper">Travel Wiper </option>
                                <option value="Pielstik/Engineer">Pielstik Engineer</option>
                                <option value="Htl/Mgr">Hotel Manager</option>
                                <option value="Purser">Purser </option>
                                <option value="Scl/Dir">Social Director </option>
                                <option value="Sprt/Dir">Sports Director </option>
                                <option value="Chef">Chef </option>
                                <option value="S/Chef">Souse Chef </option>
                                <option value="Ch/Cook">Chief Cook </option>
                                <option value="2/Cook">2nd Cook </option>
                                <option value="Chief Steward ">Chief Steward </option>
                                <option value="Stwd">Steward </option>
                                <option value="Cabin/Attd">Cabin Attendant </option>
                                <option value="Bar Tender ">Bar Tender </option>
                                <option value="Musician">Musician </option>
                                <option value="Laundry Men ">Laundry Men </option>
                                <option value="Security/Guard">Security Guard</option>
                                <option value="Safety Officer">Safety Officer</option>
                                <option value="Other rank">Other Rank</option>
                                <option value="Master">Master</option>
                                <option value="C/O">Chief Officer</option>
                                <option value="2/O">2nd Officer</option>
                                <option value="3/O">3rd Officer</option>
                                <option value="R/O">Radio Officer </option>
                                <option value="Dck/Cdt">Deck Cadet </option>
                                <option value="Tr/Cdt">Trainee Cadet </option>
                                <option value="Bosun">Bosun </option>
                                <option value="Dck/Ftr">Deck Fitter </option>
                                <option value="AB">AB </option>
                                <option value="OS">OS </option>
                                <option value="GP">GP </option>
                                <option value="Cr/Optr">Crane Operator </option>
                                <option value="Jr/O">Junior Officer</option>
                                <option value="Pumpman">Pumpman</option>
                                <option value="Fitters,Oilers">Fitters, Oilers</option>
                                <option value="Fitter">Fitter</option>
                                <option value="C/E">Chief Engineer </option>
                                <option value="2/E">2nd Engineer </option>
                                <option value="3/E">3rd Engineer </option>
                                <option value="4/E">4th Engineer </option>
                                <option value="5/E">5th Engineer </option>
                                <option value="E/E">Electrical Engineer</option>
                                <option value="E/O">Electrical Officer </option>
                                <option value="ETO">Electro Technical Officer</option>
                                <option value="Jr/E">Junior Engineer</option>
                                <option value="Asst.E/O">Asst. Electrical Officer</option>
                                <option value="Tr/E">Trainee Engineer </option>
                                <option value="R/E">Reefer Engineer </option>
                                <option value="R/Mech">Reefer Mechanic </option>
                                <option value="G/E">Gas Engineer</option>
                                <option value="E/F">Engine Fitter </option>
                                <option value="Motorman">Motorman </option>
                                <option value="Wiper">Wiper </option>
                                <option value="Trvl/Ftr">Travel Fitter </option>
                                <option value="Trvl/Wiper">Travel Wiper </option>
                                <option value="Pielstik/Engineer">Pielstik Engineer</option>
                                <option value="Htl/Mgr">Hotel Manager</option>
                                <option value="Purser">Purser </option>
                                <option value="Scl/Dir">Social Director </option>
                                <option value="Sprt/Dir">Sports Director </option>
                                <option value="Chef">Chef </option>
                                <option value="S/Chef">Souse Chef </option>
                                <option value="Ch/Cook">Chief Cook </option>
                                <option value="2/Cook">2nd Cook </option>
                                <option value="Ch/Stwd">Chief Steward </option>
                                <option value="Stwd">Steward </option>
                                <option value="Cabin/Attd">Cabin Attendant </option>
                                <option value="Bar/Tdr">Bar Tender </option>
                                <option value="Musician">Musician </option>
                                <option value="Lndr/Men">Laundry Men </option>
                                <option value="Security/Guard">Security Guard</option>
                                <option value="S.O.">Safety Officer</option>
                                <option value="othere">Other</option>
                                <option value="Master">Master</option>
                                <option value="C/O">Chief Officer</option>
                                <option value="2/O">2nd Officer</option>
                                <option value="3/O">3rd Officer</option>
                                <option value="R/O">Radio Officer </option>
                                <option value="Dck/Cdt">Deck Cadet </option>
                                <option value="Tr/Cdt">Trainee Cadet </option>
                                <option value="Bosun">Bosun </option>
                                <option value="Dck/Ftr">Deck Fitter </option>
                                <option value="AB">AB </option>
                                <option value="OS">OS </option>
                                <option value="GP">GP </option>
                                <option value="Cr/Optr">Crane Operator </option>
                                <option value="Jr/O">Junior Officer</option>
                                <option value="Pumpman">Pumpman</option>
                                <option value="Fitters,Oilers">Fitters, Oilers</option>
                                <option value="Fitter">Fitter</option>
                                <option value="C/E">Chief Engineer </option>
                                <option value="2/E">2nd Engineer </option>
                                <option value="3/E">3rd Engineer </option>
                                <option value="4/E">4th Engineer </option>
                                <option value="5/E">5th Engineer </option>
                                <option value="E/E">Electrical Engineer</option>
                                <option value="E/O">Electrical Officer </option>
                                <option value="ETO">Electro Technical Officer</option>
                                <option value="Jr/E">Junior Engineer</option>
                                <option value="Asst.E/O">Asst. Electrical Officer</option>
                                <option value="Tr/E">Trainee Engineer </option>
                                <option value="R/E">Reefer Engineer </option>
                                <option value="R/Mech">Reefer Mechanic </option>
                                <option value="G/E">Gas Engineer</option>
                                <option value="E/F">Engine Fitter </option>
                                <option value="Motorman">Motorman </option>
                                <option value="Wiper">Wiper </option>
                                <option value="Trvl/Ftr">Travel Fitter </option>
                                <option value="Trvl/Wiper">Travel Wiper </option>
                                <option value="Pielstik/Engineer">Pielstik Engineer</option>
                                <option value="Htl/Mgr">Hotel Manager</option>
                                <option value="Purser">Purser </option>
                                <option value="Scl/Dir">Social Director </option>
                                <option value="Sprt/Dir">Sports Director </option>
                                <option value="Chef">Chef </option>
                                <option value="S/Chef">Souse Chef </option>
                                <option value="Ch/Cook">Chief Cook </option>
                                <option value="2/Cook">2nd Cook </option>
                                <option value="Ch/Stwd">Chief Steward </option>
                                <option value="Stwd">Steward </option>
                                <option value="Cabin/Attd">Cabin Attendant </option>
                                <option value="Bar/Tdr">Bar Tender </option>
                                <option value="Musician">Musician </option>
                                <option value="Lndr/Men">Laundry Men </option>
                                <option value="Security/Guard">Security Guard</option>
                                <option value="S.O.">Safety Officer</option>
                                <optgroup label="  --Navigation Dept--">
                                <option value="Master">Master</option>
                                <option value="C/O">Chief Officer</option>
                                <option value="2/O">2nd Officer</option>
                                <option value="3/O">3rd Officer</option>
                                <option value="R/O">Radio Officer </option>
                                <option value="Dck/Cdt">Deck Cadet </option>
                                <option value="Tr/Cdt">Trainee Cadet </option>
                                <option value="Bosun">Bosun </option>
                                <option value="Dck/Ftr">Deck Fitter </option>
                                <option value="AB">AB </option>
                                <option value="OS">OS </option>
                                <option value="GP">GP </option>
                                <option value="Cr/Optr">Crane Operator </option>
                                <option value="Jr/O">Junior Officer</option>
                                <option value="Pumpman">Pumpman</option>
                                <option value="Fitters,Oilers">Fitters, Oilers</option>
                                <option value="Fitter">Fitter</option>
                                </optgroup>
                                <optgroup label="  --Engineering Dept--">
                                <option value="C/E">Chief Engineer </option>
                                <option value="2/E">2nd Engineer </option>
                                <option value="3/E">3rd Engineer </option>
                                <option value="4/E">4th Engineer </option>
                                <option value="5/E">5th Engineer </option>
                                <option value="E/E">Electrical Engineer</option>
                                <option value="E/O">Electrical Officer </option>
                                <option value="ETO">Electro Technical Officer</option>
                                <option value="Jr/E">Junior Engineer</option>
                                <option value="Asst.E/O">Asst. Electrical Officer</option>
                                <option value="Tr/E">Trainee Engineer </option>
                                <option value="R/E">Reefer Engineer </option>
                                <option value="R/Mech">Reefer Mechanic </option>
                                <option value="G/E">Gas Engineer</option>
                                <option value="E/F">Engine Fitter </option>
                                <option value="Motorman">Motorman </option>
                                <option value="Wiper">Wiper </option>
                                <option value="Trvl/Ftr">Travel Fitter </option>
                                <option value="Trvl/Wiper">Travel Wiper </option>
                                <option value="Pielstik/Engineer">Pielstik Engineer</option>
                                </optgroup>
                                <optgroup label="  --Hotel Dept--">
                                <option value="Htl/Mgr">Hotel Manager</option>
                                <option value="Purser">Purser </option>
                                <option value="Scl/Dir">Social Director </option>
                                <option value="Sprt/Dir">Sports Director </option>
                                <option value="Chef">Chef </option>
                                <option value="S/Chef">Souse Chef </option>
                                <option value="Ch/Cook">Chief Cook </option>
                                <option value="2/Cook">2nd Cook </option>
                                <option value="Ch/Stwd">Chief Steward </option>
                                <option value="Stwd">Steward </option>
                                <option value="Cabin/Attd">Cabin Attendant </option>
                                <option value="Bar/Tdr">Bar Tender </option>
                                <option value="Musician">Musician </option>
                                <option value="Lndr/Men">Laundry Men </option>
                                <option value="Security/Guard">Security Guard</option>
                                <option value="S.O.">Safety Officer</option>
                                </optgroup>
                    </select>
                </div>
                    <div>
                    <label>Ship</label>
                        <select class="form-control form-group" name="ship" required >
                            <option selected="selected">-- Select Ships --</option>
                                <option value="Bulk Carrier">Bulk Carrier</option>
                                <option value="Car Carrier">Car Carrier</option>
                                <option value="Oil Tanker">Oil Tanker</option>
                                <option value="Chemical Tanker">Chemical Tanker</option>
                                <option value="VLCC">VLCC</option>
                                <option value="LPG Carrier">LPG Carrier</option>
                                <option value="Container">Container</option>
                                <option value="Dry Cargo">Dry Cargo</option>
                                <option value="Reefer">Reefer</option>
                                <option value="Reefer container">Reefer container</option>
                                <option value="RORO">RORO</option>
                                <option value="OBO">OBO</option>
                                <option value="Multi-Purpose Vessel">Multi-Purpose Vessel</option>
                                <option value="Cruise Ship">Cruise Ship</option>
                                <option value="Offshore Vessel ">Offshore Vessel </option>
                                <option value="Coastal Vessel ">Coastal Vessel </option>
                                <option value="TUG ">TUG </option>
                                <option value="Dredger">Dredger</option>
                                <option value="General Cargo ">General Cargo </option>
                                <option value="Product Tanker ">Product Tanker </option>
                                <option value="Survey Vessel ">Survey Vessel </option>
                                <option value="Wood/Log Carrier ">Wood/Log Carrier </option>
                                <option value="Fishing Vessel ">Fishing Vessel </option>
                                <option value="LNG Carrier">LNG Carrier</option>
                                <option value="Aframax Tanker">Aframax Tanker</option>
                                <option value="Crude Oil Tanker">Crude Oil Tanker</option>
                                <option value="D P Vessel">D P Vessel</option>
                                <option value="FPSO">FPSO</option>
                                <option value="othere">Other</option>

                        </select>
                </div>
                <div>
                    <label>No. of Vacancy</label>
                    <input type="number" name="post" class="form-control form-group" required>
                </div>
                <div>
                    <label>Apply Till</label>
                    <input type="date" class="form-control form-group" name="aptill" required >
                </div>
                <br/>
                <div>
                    <input type="submit" value="Post Job" class="btn form-control form-group" name="submit">
                    <br/>
                    <br/>
                    <input type="Reset" value="Reset" class="btn form-control form-group">
                </div>
            </form>

                
            </div>
            <div class="col-lg-3 ">
                <?php include_once("includes/rightpanel.php");?>
            
            </div>
        </div>
        <?php include_once("includes/footer.php");?>
    </body>
</html>
