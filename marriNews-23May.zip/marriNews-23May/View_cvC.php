<?php
session_start();
include_once("redirect/redirect.php");
mysql_connect("localhost","root","") or die("Connection Error");
mysql_select_db("maritime") or die("Database not found");
error_reporting(0);
$_SESSION['u'];

$query="SELECT canemail FROM japp where cemail='".$_SESSION['u']."'";
            $result = mysql_query($query);
$i=0;
while($row=mysql_fetch_array($result))
{
     $query1="SELECT * FROM candidate where caemail='".$row[0]."'";
    $result1 = mysql_query($query1);
    $row1=mysql_fetch_array($result1);
    $row11[$i]=$row1;
    $i=$i+1;
}


?>
<html>
    <head>
        <title>Company Login</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    <!-- Optional theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
        <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="CSS/style.css"/>

    
    </head>
    <body>
        
        <div class="container-fluid">
             <?php include_once("includes/header.php");?>
        <div class="row">
        <div class="container">
            <?php include_once("includes/leftpanel.php");?>
            </div>
            <div class="col-lg-6">
                <form>
                    <div>
                        <table class="table table-bordered">
                            <tr>
                                <th>Sno.</th>       
                                <th>Candidate Name</th>
                                <th>Rank</th>
                                <th>Ship</th>
                                <th>View Profile</th>
                            </tr>
                            
                            <?php
                           for($k=0;$k<$i;$k++)
                            {
                            ?>
                            <tr>
                                <td><?php echo $k+1;?></td>       
                                <td><?php echo $row11[$k][1];?></td>
                                <td><?php echo $row11[$k][9];?></td>
                                <td><?php echo $row11[$k][10];?></td>
                                <td><a href="view_candidate.php?id=<?php echo $row11[$k][0]; ?>" >View Profile</a></td>
                            </tr>
                            <?php
                            }
                            ?>
                            
                                                    </table>
                    </div>
                </form>
              </div>
            <div class="col-lg-3 ">
               <?php include_once("includes/rightpanel.php");?>
            </div>
            </div>
            </div>
            <?php include_once("includes/footer.php");?>
    </body>
</html>